<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Verify_unzip_message</name>
   <tag></tag>
   <elementGuidId>f297f835-8b5a-4d3a-9924-5cd0447bb400</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[(text() = 'Do you want to unzip the file?' or . = 'Do you want to unzip the file?')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Do you want to unzip the file?')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Do you want to unzip the file?</value>
   </webElementProperties>
</WebElementEntity>
