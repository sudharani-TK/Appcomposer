<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Icon_DeleteFile</name>
   <tag></tag>
   <elementGuidId>941ee561-4c8f-48cc-ae6d-6432afcdf090</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@class='file-content-viewer-action-bar-item '][@title='Delete']//img[contains(@src,'.svg')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
