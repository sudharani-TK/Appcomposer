<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Link_JobName_xpath</name>
   <tag></tag>
   <elementGuidId>3812d4e0-ed0c-4b3b-9de6-2c24a063a75f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='job-bread-crumb-item parent-job-bread-crumb-item']//a[@class='show-text-ellipsis focus_enable_class']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
