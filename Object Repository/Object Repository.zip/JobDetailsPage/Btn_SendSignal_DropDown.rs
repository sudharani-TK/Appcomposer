<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Btn_SendSignal_DropDown</name>
   <tag></tag>
   <elementGuidId>cb7d85c2-6534-4f1f-94bb-aca28a6f5af8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='submission_signal_field_input']//div[@class='theme-receiver rw-widget-input rw-widget-picker rw-widget-container']//span[@class='rw-select']//button[@type='button']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
