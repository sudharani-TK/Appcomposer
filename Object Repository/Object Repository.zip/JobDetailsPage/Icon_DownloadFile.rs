<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Icon_DownloadFile</name>
   <tag></tag>
   <elementGuidId>dc82ccd5-4f95-4955-96d3-d173861dd26a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@class='file-content-viewer-action-bar-item '][@title='Download']//img[contains(@src,'.svg')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
