<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dialog_CancelEdit</name>
   <tag></tag>
   <elementGuidId>0666664a-45b9-4559-a297-c268e815f1cf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class = 'dialog-title' and (text() = 'Cancel Editing?' or . = 'Cancel Editing?')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//div[@class = 'dialog-title' and (text() = 'Cancel Editing?' or . = 'Cancel Editing?')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dialog-title</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Cancel Editing?</value>
   </webElementProperties>
</WebElementEntity>
