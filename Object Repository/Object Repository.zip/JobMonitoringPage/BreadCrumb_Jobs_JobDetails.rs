<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BreadCrumb_Jobs_JobDetails</name>
   <tag></tag>
   <elementGuidId>f44b516f-1fda-4f2e-95e8-8150f41c97df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@class='show-text-ellipsis focus_enable_class'][contains(text(),'Jobs')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//span[(contains(text(), 'Job Metadata') or contains(., 'Job Metadata'))]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Job Metadata</value>
   </webElementProperties>
</WebElementEntity>
