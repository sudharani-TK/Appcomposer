<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Userinfo</name>
   <tag></tag>
   <elementGuidId>f5142beb-9b66-48b0-8e3b-153313a09601</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = 'sami' or . = 'sami')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//div[(text() = 'sami' or . = 'sami')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>sami</value>
   </webElementProperties>
</WebElementEntity>
