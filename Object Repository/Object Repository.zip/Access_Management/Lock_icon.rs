<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Lock_icon</name>
   <tag></tag>
   <elementGuidId>86fb1294-e829-4731-a370-d7350b153e7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(@class,'ag-body-viewport ag-row-no-animation ag-layout-auto-height')]//div[3]//div[2]//div[1]//div[1]//span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
