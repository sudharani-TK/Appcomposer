<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Selectrole</name>
   <tag></tag>
   <elementGuidId>e48cf0e7-023d-4e8e-a96a-b1dd9d1db522</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;root&quot;)/div[1]/div[@class=&quot;tabs&quot;]/div[@class=&quot;tabs__content&quot;]/div[@class=&quot;user-roles&quot;]/div[@class=&quot;user-roles-inner-div&quot;]/div[@class=&quot;user-roles-content-tab&quot;]/div[@class=&quot;user-roles-tabs&quot;]/div[@class=&quot;user-roles-topic-content-tab&quot;]/div[@class=&quot;user-roles-tab-content&quot;]/div[1]/div[@class=&quot;user-roles-list&quot;]/div[@class=&quot;white-theme&quot;]/div[@class=&quot;list_loader_wrapper css-79elbk&quot;]/div[1]/div[1]/div[@class=&quot;data-grid-wrapper  row-selector&quot;]/div[1]/div[@class=&quot;ag-root-wrapper ag-ltr ag-layout-auto-height&quot;]/div[@class=&quot;ag-root-wrapper-body ag-layout-auto-height&quot;]/div[@class=&quot;ag-root ag-unselectable ag-layout-auto-height&quot;]/div[@class=&quot;ag-body-viewport ag-row-no-animation ag-layout-auto-height&quot;]/div[@class=&quot;ag-center-cols-clipper&quot;]/div[@class=&quot;ag-center-cols-viewport&quot;]/div[@class=&quot;ag-center-cols-container&quot;]/div[@class=&quot;ag-row ag-row-no-focus ag-row-odd ag-row-level-0 ag-row-position-absolute ag-row-last ag-row-hover&quot;]/div[@class=&quot;ag-cell ag-cell-not-inline-editing ag-cell-with-height ag-column-hover&quot;]/div[@class=&quot;ag-cell-wrapper&quot;]/span[@class=&quot;ag-selection-checkbox&quot;]/span[@class=&quot;ag-icon ag-icon-checkbox-unchecked&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@class='ag-icon ag-icon-checkbox-unchecked']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ag-row.ag-row-no-focus.ag-row-odd.ag-row-level-0.ag-row-position-absolute.ag-row-last.ag-row-hover > div.ag-cell.ag-cell-not-inline-editing.ag-cell-with-height.ag-column-hover > div.ag-cell-wrapper > span.ag-selection-checkbox > span.ag-icon.ag-icon-checkbox-unchecked</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ag-icon ag-icon-checkbox-unchecked</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>unselectable</name>
      <type>Main</type>
      <value>on</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[1]/div[@class=&quot;tabs&quot;]/div[@class=&quot;tabs__content&quot;]/div[@class=&quot;user-roles&quot;]/div[@class=&quot;user-roles-inner-div&quot;]/div[@class=&quot;user-roles-content-tab&quot;]/div[@class=&quot;user-roles-tabs&quot;]/div[@class=&quot;user-roles-topic-content-tab&quot;]/div[@class=&quot;user-roles-tab-content&quot;]/div[1]/div[@class=&quot;user-roles-list&quot;]/div[@class=&quot;white-theme&quot;]/div[@class=&quot;list_loader_wrapper css-79elbk&quot;]/div[1]/div[1]/div[@class=&quot;data-grid-wrapper  row-selector&quot;]/div[1]/div[@class=&quot;ag-root-wrapper ag-ltr ag-layout-auto-height&quot;]/div[@class=&quot;ag-root-wrapper-body ag-layout-auto-height&quot;]/div[@class=&quot;ag-root ag-unselectable ag-layout-auto-height&quot;]/div[@class=&quot;ag-body-viewport ag-row-no-animation ag-layout-auto-height&quot;]/div[@class=&quot;ag-center-cols-clipper&quot;]/div[@class=&quot;ag-center-cols-viewport&quot;]/div[@class=&quot;ag-center-cols-container&quot;]/div[@class=&quot;ag-row ag-row-no-focus ag-row-odd ag-row-level-0 ag-row-position-absolute ag-row-last ag-row-hover&quot;]/div[@class=&quot;ag-cell ag-cell-not-inline-editing ag-cell-with-height ag-column-hover&quot;]/div[@class=&quot;ag-cell-wrapper&quot;]/span[@class=&quot;ag-selection-checkbox&quot;]/span[@class=&quot;ag-icon ag-icon-checkbox-unchecked&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[3]/div/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/span/span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/span/span[2]</value>
   </webElementXpaths>
</WebElementEntity>
