<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Verify_user</name>
   <tag></tag>
   <elementGuidId>b8e05d93-400a-441b-9fc1-ca0c3d66ac02</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(@class,'ag-row ag-row-no-focus ag-row-odd ag-row-level-0 ag-row-position-absolute')]//div[contains(@class,'ag-cell ag-cell-not-inline-editing ag-cell-with-height ag-cell-value')]//div[contains(@class,'ag-react-container')]//div//a[contains(text(),'sami')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
