<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Checkuser</name>
   <tag></tag>
   <elementGuidId>db09ba6b-f055-4b12-bd02-ad1896648fcd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(@class,'ag-cell ag-cell-not-inline-editing ag-cell-with-height ag-cell-focus')]//span[contains(@class,'ag-icon ag-icon-checkbox-checked')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
