<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Qstat_of_Job</name>
   <tag></tag>
   <elementGuidId>065b3883-33b8-43c0-8992-b0b01772710f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[(text() = 'Qstat of Job (hpccluster)' or . = 'Qstat of Job (hpccluster)')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Qstat of Job (hpccluster)')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Qstat of Job (hpccluster)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
</WebElementEntity>
