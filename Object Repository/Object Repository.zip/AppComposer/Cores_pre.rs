<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Cores_pre</name>
   <tag></tag>
   <elementGuidId>032050cc-39f1-4acb-85e2-034d739e8935</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#submission_ncpus_field > div.theme-receiver.rw-widget-picker.rw-widget-container</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='submission_ncpus_field']//div[@class='theme-receiver rw-widget-picker rw-widget-container']//input[@type='text']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;submission_ncpus_field&quot;)/div[@class=&quot;theme-receiver rw-widget-picker rw-widget-container&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>theme-receiver rw-widget-picker rw-widget-container</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;submission_ncpus_field&quot;)/div[@class=&quot;theme-receiver rw-widget-picker rw-widget-container&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='submission_ncpus_field']/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Number of Cores'])[2]/following::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Walltime'])[2]/following::div[9]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Input File'])[2]/preceding::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[3]/div/div/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
