<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cores_vlaue</name>
   <tag></tag>
   <elementGuidId>e13444e3-621d-483e-b1be-859c663b6efd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ncpus_value_input']//div[@class='theme-receiver rw-widget-picker rw-widget-container']//input[@type='text']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
