<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Cloneapp</name>
   <tag></tag>
   <elementGuidId>c8bcde1a-c2c7-4b61-be99-babc55ff6b47</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
