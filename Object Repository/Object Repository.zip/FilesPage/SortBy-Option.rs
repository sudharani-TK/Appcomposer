<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SortBy-Option</name>
   <tag></tag>
   <elementGuidId>d93f00bb-df71-44c9-81c7-f8dd3b4f9e40</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='rw-input rw-dropdown-list-input']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//span[@class = 'rw-dropdown-list-value']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>rw-dropdown-list-value</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
</WebElementEntity>
