<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SortLableTileView</name>
   <tag></tag>
   <elementGuidId>052843d7-4b18-44ca-87f8-bfcc2d9e6881</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),'Sort Order')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//label[(text() = 'Sort Order' or . = 'Sort Order') and @id = 'tile-columns-sortable-label']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sort Order</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>tile-columns-sortable-label</value>
   </webElementProperties>
</WebElementEntity>
