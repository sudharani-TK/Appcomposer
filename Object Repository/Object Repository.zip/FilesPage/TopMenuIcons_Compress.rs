<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TopMenuIcons_Compress</name>
   <tag></tag>
   <elementGuidId>ed806aaf-6e82-46ee-8845-56284a683852</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//nav[@class='react-contextmenu react-contextmenu--visible']//span[@id='Compress']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
