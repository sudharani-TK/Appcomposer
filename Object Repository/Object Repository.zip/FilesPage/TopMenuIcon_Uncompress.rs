<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TopMenuIcon_Uncompress</name>
   <tag></tag>
   <elementGuidId>05d3e49b-de1e-43b2-8dc7-865f70448c4b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//nav[@class='react-contextmenu react-contextmenu--visible']//span[@id='Uncompress']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
