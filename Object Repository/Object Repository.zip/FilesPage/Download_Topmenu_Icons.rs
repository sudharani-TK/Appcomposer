<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Download_Topmenu_Icons</name>
   <tag></tag>
   <elementGuidId>399c538b-7aa4-49f3-9c08-763c6b0c803b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[contains(@class,'react-contextmenu react-contextmenu--visible')]//span[@id='Download']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
