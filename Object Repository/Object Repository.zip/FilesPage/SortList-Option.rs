<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SortList-Option</name>
   <tag></tag>
   <elementGuidId>d5460e31-fc10-429d-a3cd-df3c3d74a5ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[(text() = 'Created On' or . = 'Created On')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(text(),'Created On')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Created On</value>
   </webElementProperties>
</WebElementEntity>
