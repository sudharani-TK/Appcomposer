<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SelectallFiles</name>
   <tag></tag>
   <elementGuidId>e9b1e7f8-5aca-4c1e-9667-385075e6ad85</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='ag-header-select-all ag-labeled ag-label-align-right ag-checkbox']//div[@class='ag-wrapper ag-input-wrapper']//div//span[@class='ag-icon ag-icon-checkbox-unchecked']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//div[@class = 'ag-header-select-all ag-labeled ag-label-align-right ag-checkbox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ag-header-select-all ag-labeled ag-label-align-right ag-checkbox</value>
   </webElementProperties>
</WebElementEntity>
