<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Label_FolderEmpty</name>
   <tag></tag>
   <elementGuidId>2c6c209a-b995-480d-810e-5ea5cecb07e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='emptymessage-img']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//div[(text() = 'This folder is empty' or . = 'This folder is empty')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>This folder is empty</value>
   </webElementProperties>
</WebElementEntity>
