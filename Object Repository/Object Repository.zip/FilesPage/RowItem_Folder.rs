<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>RowItem_Folder</name>
   <tag></tag>
   <elementGuidId>dd82c5f3-1f9a-47d8-8fdc-d4f9c1fb1411</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = 'Myfile' )]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//div[@title = 'MyFolder']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>MyFolder</value>
   </webElementProperties>
</WebElementEntity>
