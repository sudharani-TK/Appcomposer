<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TopMenuIcons_Paste</name>
   <tag></tag>
   <elementGuidId>c2bbcf1e-b97e-48de-9644-300d87db160a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//nav[@class='react-contextmenu react-contextmenu--visible']//span[@id='Paste']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
