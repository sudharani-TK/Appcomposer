<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Columnname</name>
   <tag></tag>
   <elementGuidId>6029b0f5-e970-4212-9bc8-bc7bf864b6e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[(text() = 'File Extension' or . = 'File Extension')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'File Path')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>File Extension</value>
   </webElementProperties>
</WebElementEntity>
