<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Managebookmark</name>
   <tag></tag>
   <elementGuidId>8c073368-cef2-4a00-ac43-e011497f1517</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[(text() = 'Manage Bookmarks' or . = 'Manage Bookmarks')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Manage Bookmarks')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Manage Bookmarks</value>
   </webElementProperties>
</WebElementEntity>
