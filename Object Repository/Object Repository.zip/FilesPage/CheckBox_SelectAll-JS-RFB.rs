<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CheckBox_SelectAll-JS-RFB</name>
   <tag></tag>
   <elementGuidId>2c754720-4991-41d8-84c8-a99b823760ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='ag-header-select-all ag-labeled ag-label-align-right ag-checkbox']//span[@class='ag-icon ag-icon-checkbox-unchecked']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
