<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Createbookmark</name>
   <tag></tag>
   <elementGuidId>d8f6d16c-1657-4cc1-add9-600773ac4a8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id = 'bookMarkIcon' and (text() = 'Create BookmarkManage Bookmarks' or . = 'Create BookmarkManage Bookmarks')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//li[@id = 'create_favorite']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>create_favorite</value>
   </webElementProperties>
</WebElementEntity>
