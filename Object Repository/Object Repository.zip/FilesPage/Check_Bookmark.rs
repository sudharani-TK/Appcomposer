<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Check_Bookmark</name>
   <tag></tag>
   <elementGuidId>52347c21-b21f-4fba-ad26-b618d5c81e07</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'New bookmark')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//a[(contains(text(), 'NewBookmark') or contains(., 'NewBookmark'))]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NewBookmark</value>
   </webElementProperties>
</WebElementEntity>
