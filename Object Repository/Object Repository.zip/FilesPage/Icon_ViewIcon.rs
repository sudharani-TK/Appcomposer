<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Icon_ViewIcon</name>
   <tag></tag>
   <elementGuidId>fd65ce85-81b7-4e1f-a785-5c71f3321cec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title = 'Tile View']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@title='Tile View']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Tile View</value>
   </webElementProperties>
</WebElementEntity>
