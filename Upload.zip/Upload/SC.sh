#!/bin/sh
ln -s /stage/$USER/InputDeck/bar.fem /stage/david/ShortCutFiles/SCbar.fem
ln -s /stage/$USER/InputDeck/RunJob.sh /stage/david/ShortCutFiles/SCRunJob.sh