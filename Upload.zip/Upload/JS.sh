#!/bin/sh
mkdir JSUploads
mkdir ShortCutFiles