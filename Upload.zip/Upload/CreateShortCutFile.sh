#!/bin/sh
cd /stage/$USER/ShortCutFiles
ln -s /stage/$USER/InputDeck/RunJob.sh ShortCutRunJob.sh